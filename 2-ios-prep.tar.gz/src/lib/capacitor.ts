import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { SplashScreen } from '@capacitor/splash-screen';

export const isNativePlatform = () => Capacitor.isNativePlatform();
export const getPlatform = () => Capacitor.getPlatform();

/**
 * Initializes native mobile features when running inside Capacitor (Android / iOS).
 * - Matches Status Bar color with the brand theme (#045353)
 * - Intercepts hardware Back button on Android to navigate back instead of exiting
 * - Dismisses splash screen smoothly once the app is loaded
 */
export async function initCapacitorApp(): Promise<void> {
  if (!Capacitor.isNativePlatform()) {
    return;
  }

  try {
    // 1. Configure Status Bar
    await StatusBar.setStyle({ style: Style.Dark });
    if (Capacitor.getPlatform() === 'android') {
      await StatusBar.setBackgroundColor({ color: '#045353' });
      await StatusBar.setOverlaysWebView({ overlay: false });
    }
  } catch (err) {
    console.warn('[Capacitor] StatusBar init error:', err);
  }

  try {
    // 2. Android Hardware Back Button navigation
    App.addListener('backButton', ({ canGoBack }) => {
      // If modal or dialog is open, or history can go back
      if (window.history.length > 1 && canGoBack) {
        window.history.back();
      } else {
        // At root page: minimize / exit
        App.exitApp();
      }
    });
  } catch (err) {
    console.warn('[Capacitor] BackButton listener error:', err);
  }

  try {
    // 3. Dismiss Splash Screen
    await SplashScreen.hide();
  } catch (err) {
    console.warn('[Capacitor] SplashScreen hide error:', err);
  }

  try {
    // 4. Handle Deep Linking for OAuth (e.g. returning from Chrome back into app)
    App.addListener('appUrlOpen', async ({ url }) => {
      try {
        try {
          const { Browser } = await import('@capacitor/browser');
          await Browser.close();
        } catch {
          // Browser sheet not open (Android) - nothing to close
        }
        const parsed = new URL(url);
        // Supabase sends tokens in URL fragment (#access_token=...&refresh_token=...)
        if (parsed.hash) {
          const hashParams = new URLSearchParams(parsed.hash.replace(/^#/, ''));
          const accessToken = hashParams.get('access_token');
          const refreshToken = hashParams.get('refresh_token');
          if (accessToken && refreshToken) {
            const { supabase } = await import('@/integrations/supabase/client');
            await supabase.auth.setSession({
              access_token: accessToken,
              refresh_token: refreshToken,
            });
            window.location.href = '/';
          }
        }
      } catch (err) {
        console.warn('[Capacitor] appUrlOpen error:', err);
      }
    });
  } catch (err) {
    console.warn('[Capacitor] appUrlOpen listener setup error:', err);
  }

  try {
    // 5. Native Push Notifications Registration (Android / iOS)
    const { PushNotifications } = await import('@capacitor/push-notifications');

    let permStatus = await PushNotifications.checkPermissions();
    if (permStatus.receive === 'prompt') {
      permStatus = await PushNotifications.requestPermissions();
    }

    if (permStatus.receive === 'granted') {
      // Create high-importance Android notification channel for orders & chat alerts
      if (Capacitor.getPlatform() === 'android') {
        await PushNotifications.createChannel({
          id: 'orders_channel',
          name: 'طلبات وتنبيهات موجود',
          description: 'تنبيهات فورية بحالات الطلبات ومحادثات المتاجر والدليفري',
          importance: 5,
          visibility: 1,
          sound: 'default',
          vibration: true,
        });
      }

      await PushNotifications.register();

      PushNotifications.addListener('registration', async (token) => {
        try {
          const { registerPushDevice } = await import('@/lib/push.functions');
          await registerPushDevice({
            data: {
              token: token.value,
            },
          });
        } catch (tokErr) {
          console.warn('[Capacitor] Push token save error:', tokErr);
        }
      });

      PushNotifications.addListener('pushNotificationActionPerformed', (notification) => {
        const data = notification.notification.data;
        const targetPath = data?.path || data?.link || '/orders';
        if (targetPath) {
          window.location.href = targetPath;
        }
      });
    }
  } catch (pushErr) {
    console.warn('[Capacitor] Native PushNotifications setup notice:', pushErr);
  }
}
